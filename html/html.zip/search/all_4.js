var searchData=
[
  ['freeinstance',['freeInstance',['../d7/dae/classMP3enc.html#ae0daed236d352bc8f35ba6f8885d3885',1,'MP3enc']]]
];
